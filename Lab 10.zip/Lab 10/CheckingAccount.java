public class CheckingAccount extends BankAccount
{
	// To do - Task #1 step 3
	// define a private static doubl field
        private static double FEE = 0.15;
	// named FEE and set the initial value as 15 cents
	
	public CheckingAccount(String name, double begBal)
	{
		super(name, begBal);
		// To do - Task #1 step 4
		// using the inherited method
		// getAccountNumber, then concatenated with �10 
                String accountNum = super.getAccountNumber() + "-10";
		// then using the inherited method
		// setAccountNumber
                super.setAccountNumber(accountNum);
	}
	
	public boolean withdraw (double amount) // overide the method
	{
		// To do - Task #1 step 5
		// add FEE to the amount then call
		// super.withdraw(amount);
		// and return the result
            
            double newAmount = amount + FEE;
            return super.withdraw(newAmount);
	}
        
        
}