public class SavingsAccount extends BankAccount
{
	private double rate = .025;	//annual rate
	// To do - Task #2 step 2, 3
	// define integer savingsNumber and initiate it as 0
        int savingsNumber = 0;
	// define String accountNumber
	String accountNumber;
        
	public SavingsAccount(String name, double begBal)
	{
		// To do - Finish Task #2 step 4 to call super class constructor
		// with name and begBal as parameter
                super(name, begBal);
		accountNumber = super.getAccountNumber() + "-" + savingsNumber;
	}
	
	public SavingsAccount(SavingsAccount oldAccount, double begBal)
	{
                super(oldAccount, begBal);
		// To do - Finish Task #2 step 7
		// add 1 to oldAccount.savingsNumber
                int newSavingsNumber = oldAccount.savingsNumber + 1;
		// also assign accountNumber, reference to Task#2 step 4
                accountNumber = super.getAccountNumber() + "-" + newSavingsNumber;
                
	} 
		
	public void postInterest( )
	{
		// To do - Finish Task #2 step 5
		// use getBalance to get current balance
                double bal = super.getBalance();
		// add monthly interest (rate/12) then use setBalance to set
                bal += (rate/12);
		// the new balance into the account.
                super.setBalance(bal);
	}
	
	// To do - Finish Task #2 step 6
        @Override
        public String getAccountNumber(){
            return accountNumber;
        }
}